package com.example.mescourses.activities;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mescourses.R;
import com.example.mescourses.adapters.ArchivageAdapter;
import com.example.mescourses.database.DatabaseHelper;
import com.example.mescourses.models.Produit;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class ArchivageActivity extends AppCompatActivity {

    private RecyclerView      recyclerView;
    private TextView          tvEmpty;
    private ArchivageAdapter  adapter;
    private DatabaseHelper    db;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archivage);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        db           = DatabaseHelper.getInstance(this);
        recyclerView = findViewById(R.id.recyclerViewArchivage);
        tvEmpty      = findViewById(R.id.tvEmpty);
        fab          = findViewById(R.id.fabAjouter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        chargerArchivage();
        attachSwipe();

        // FAB → AlertDialog pour ajouter un produit directement en archivage
        fab.setOnClickListener(v -> showAjoutDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();
        chargerArchivage();
    }

    private void chargerArchivage() {
        List<Produit> list = db.getProduitsArchives();

        if (adapter == null) {
            adapter = new ArchivageAdapter(list, (produit, position) -> {
                // Clic sur un article archivé → modifier quantité
                showModifQuantiteDialog(produit);
            });
            recyclerView.setAdapter(adapter);
        } else {
            adapter.updateList(list);
        }

        tvEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** Dialog modification quantité d'un article archivé */
    private void showModifQuantiteDialog(Produit produit) {
        String[] options = {"Modifier la quantité", "Modifier le produit complet", "Annuler"};

        new AlertDialog.Builder(this)
            .setTitle(produit.getNom())
            .setItems(options, (dialog, which) -> {
                switch (which) {
                    case 0:
                        showQuantiteSeuleDialog(produit);
                        break;
                    case 1:
                        Intent intent = new Intent(this, ModifQuantiteActivity.class);
                        intent.putExtra("produit_id", produit.getId());
                        startActivity(intent);
                        break;
                }
            }).show();
    }

    /** Dialog pour modifier uniquement la quantité */
    private void showQuantiteSeuleDialog(Produit produit) {
        View v = LayoutInflater.from(this)
            .inflate(android.R.layout.simple_list_item_1, null);

        android.widget.EditText etQ = new android.widget.EditText(this);
        etQ.setHint("Nouvelle quantité");
        etQ.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etQ.setText(String.valueOf(produit.getQuantite()));
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setPadding(48, 24, 48, 0);
        layout.addView(etQ);

        new AlertDialog.Builder(this)
            .setTitle("Quantité — " + produit.getNom())
            .setView(layout)
            .setPositiveButton("Enregistrer", (d, w) -> {
                String val = etQ.getText().toString().trim();
                if (val.isEmpty()) {
                    Toast.makeText(this, "Entrez une quantité", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    int q = Integer.parseInt(val);
                    if (q <= 0) throw new NumberFormatException();
                    db.updateProduit(produit.getId(), produit.getNom(), q, produit.getRayon());
                    Toast.makeText(this, "Quantité mise à jour", Toast.LENGTH_SHORT).show();
                    chargerArchivage();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Quantité invalide", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Annuler", null)
            .show();
    }

    /** FAB → Ajouter un nouveau produit directement en archivage */
    private void showAjoutDialog() {
        View dialogView = LayoutInflater.from(this)
            .inflate(R.layout.activity_modif_quantite, null);

        TextInputEditText etNom = dialogView.findViewById(R.id.etNom);
        TextInputEditText etQ   = dialogView.findViewById(R.id.etQuantite);
        TextInputEditText etR   = dialogView.findViewById(R.id.etRayon);

        new AlertDialog.Builder(this)
            .setTitle("Ajouter un produit")
            .setView(dialogView)
            .setPositiveButton("Ajouter", (d, w) -> {
                String nom   = etNom.getText() != null ? etNom.getText().toString().trim() : "";
                String qStr  = etQ.getText()   != null ? etQ.getText().toString().trim()   : "";
                String rayon = etR.getText()   != null ? etR.getText().toString().trim()   : "";

                if (nom.isEmpty() || qStr.isEmpty() || rayon.isEmpty()) {
                    Toast.makeText(this, "Tous les champs sont requis", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    int q = Integer.parseInt(qStr);
                    // Insérer en base puis passer en archivage
                    long id = db.insertProduit(nom, q, rayon);
                    if (id == -1) {
                        Toast.makeText(this, "Ce produit existe déjà", Toast.LENGTH_SHORT).show();
                    } else {
                        db.updateStatut((int) id, Produit.STATUT_ARCHIVE);
                        Toast.makeText(this, "Produit ajouté à l'archivage", Toast.LENGTH_SHORT).show();
                        chargerArchivage();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Quantité invalide", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("Annuler", null)
            .show();
    }

    private void attachSwipe() {
        ItemTouchHelper.SimpleCallback swipeCallback =
            new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(@NonNull RecyclerView rv,
                                  @NonNull RecyclerView.ViewHolder vh,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position    = viewHolder.getAdapterPosition();
                Produit produit = adapter.getItem(position);

                if (direction == ItemTouchHelper.LEFT) {
                    // Swipe droite→gauche : supprimer de la base entièrement
                    new AlertDialog.Builder(ArchivageActivity.this)
                        .setTitle("Supprimer")
                        .setMessage("Supprimer \"" + produit.getNom() + "\" définitivement ?")
                        .setPositiveButton("Supprimer", (d, w) -> {
                            db.deleteProduit(produit.getId());
                            adapter.removeItem(position);
                            Toast.makeText(ArchivageActivity.this,
                                produit.getNom() + " supprimé", Toast.LENGTH_SHORT).show();
                            mettreAJourVide();
                        })
                        .setNegativeButton("Annuler", (d, w) -> {
                            // Remettre l'item en place
                            adapter.notifyItemChanged(position);
                        })
                        .show();

                } else {
                    // Swipe gauche→droite : ajouter à la liste courses en cours
                    db.updateStatut(produit.getId(), Produit.STATUT_COURSES);
                    adapter.removeItem(position);
                    Toast.makeText(ArchivageActivity.this,
                        produit.getNom() + " ajouté aux courses",
                        Toast.LENGTH_SHORT).show();
                    mettreAJourVide();
                }
            }

            @Override
            public void onChildDraw(@NonNull Canvas c,
                                    @NonNull RecyclerView recyclerView,
                                    @NonNull RecyclerView.ViewHolder viewHolder,
                                    float dX, float dY,
                                    int actionState, boolean isCurrentlyActive) {

                View itemView  = viewHolder.itemView;
                Paint paint    = new Paint();
                Paint textPaint = new Paint();
                textPaint.setColor(Color.WHITE);
                textPaint.setTextSize(42f);
                textPaint.setAntiAlias(true);

                float itemHeight  = itemView.getBottom() - itemView.getTop();
                float cornerRadius = 16f;

                if (dX > 0) {
                    // Vert → ajouter à la liste
                    paint.setColor(Color.parseColor("#4CAF50"));
                    RectF bg = new RectF(
                        itemView.getLeft(), itemView.getTop(),
                        itemView.getLeft() + dX, itemView.getBottom());
                    c.drawRoundRect(bg, cornerRadius, cornerRadius, paint);
                    c.drawText("← Ajouter à la liste",
                        itemView.getLeft() + 30f,
                        itemView.getTop() + itemHeight / 2f + 15f, textPaint);

                } else if (dX < 0) {
                    // Rouge → supprimer
                    paint.setColor(Color.parseColor("#D64B3A"));
                    RectF bg = new RectF(
                        itemView.getRight() + dX, itemView.getTop(),
                        itemView.getRight(), itemView.getBottom());
                    c.drawRoundRect(bg, cornerRadius, cornerRadius, paint);
                    String label = "Supprimer →";
                    float tw = textPaint.measureText(label);
                    c.drawText(label,
                        itemView.getRight() - tw - 30f,
                        itemView.getTop() + itemHeight / 2f + 15f, textPaint);
                }

                super.onChildDraw(c, recyclerView, viewHolder,
                    dX, dY, actionState, isCurrentlyActive);
            }
        };

        new ItemTouchHelper(swipeCallback).attachToRecyclerView(recyclerView);
    }

    private void mettreAJourVide() {
        tvEmpty.setVisibility(adapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(adapter.getItemCount() == 0 ? View.GONE : View.VISIBLE);
    }
}
