package com.example.mescourses.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.example.mescourses.R;
import com.example.mescourses.models.SessionManager;
import com.example.mescourses.network.ApiConfig;
import com.example.mescourses.network.MySingleton;
import com.google.android.material.switchmaterial.SwitchMaterial;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfilActivity extends AppCompatActivity {

    private SessionManager session;
    private TextView       tvUsername, tvEmail, tvUserInitials;
    private LinearLayout   rowChangePassword, rowChangeEmail, rowLogout;
    private SwitchMaterial switchDarkMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        session            = new SessionManager(this);
        tvUsername         = findViewById(R.id.tvUsername);
        tvEmail            = findViewById(R.id.tvEmail);
        tvUserInitials     = findViewById(R.id.tvUserInitials);
        rowChangePassword  = findViewById(R.id.rowChangePassword);
        rowChangeEmail     = findViewById(R.id.rowChangeEmail);
        rowLogout          = findViewById(R.id.rowLogout);
        switchDarkMode     = findViewById(R.id.switchDarkMode);

        // Afficher les infos utilisateur
        String login = session.getLogin();
        String email = session.getEmail();
        tvUsername.setText(login);
        tvEmail.setText(email);
        if (!login.isEmpty()) {
            tvUserInitials.setText(String.valueOf(login.charAt(0)).toUpperCase());
        }

        // Dark mode switch
        int nightMode = AppCompatDelegate.getDefaultNightMode();
        switchDarkMode.setChecked(nightMode == AppCompatDelegate.MODE_NIGHT_YES);
        switchDarkMode.setOnCheckedChangeListener((btn, isChecked) -> {
            AppCompatDelegate.setDefaultNightMode(
                isChecked ? AppCompatDelegate.MODE_NIGHT_YES
                          : AppCompatDelegate.MODE_NIGHT_NO);
        });

        // Changer mot de passe
        rowChangePassword.setOnClickListener(v -> showChangePasswordDialog());

        // Changer email
        rowChangeEmail.setOnClickListener(v -> showChangeEmailDialog());

        // Déconnexion
        rowLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Déconnexion")
                .setMessage("Voulez-vous vraiment vous déconnecter ?")
                .setPositiveButton("Oui", (d, w) -> {
                    session.logout();
                    Intent intent = new Intent(this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                })
                .setNegativeButton("Annuler", null)
                .show();
        });
    }

    /** Dialog changement de mot de passe */
    private void showChangePasswordDialog() {
        View dialogView = LayoutInflater.from(this)
            .inflate(android.R.layout.simple_list_item_1, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Changer le mot de passe");

        // Layout inline pour les champs
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 0);

        EditText etOldPwd = new EditText(this);
        etOldPwd.setHint("Ancien mot de passe");
        etOldPwd.setInputType(android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etOldPwd);

        EditText etNewPwd = new EditText(this);
        etNewPwd.setHint("Nouveau mot de passe (min. 6 car.)");
        etNewPwd.setInputType(android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etNewPwd);

        EditText etConfirm = new EditText(this);
        etConfirm.setHint("Confirmer le nouveau mot de passe");
        etConfirm.setInputType(android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(etConfirm);

        builder.setView(layout);
        builder.setPositiveButton("Modifier", (d, w) -> {
            String oldPwd  = etOldPwd.getText().toString().trim();
            String newPwd  = etNewPwd.getText().toString().trim();
            String confirm = etConfirm.getText().toString().trim();

            if (oldPwd.isEmpty() || newPwd.isEmpty()) {
                Toast.makeText(this, "Remplissez tous les champs", Toast.LENGTH_SHORT).show();
                return;
            }
            if (newPwd.length() < 6) {
                Toast.makeText(this, "Nouveau mot de passe trop court", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!newPwd.equals(confirm)) {
                Toast.makeText(this, "Les mots de passe ne correspondent pas", Toast.LENGTH_SHORT).show();
                return;
            }
            changerMotDePasse(oldPwd, newPwd);
        });
        builder.setNegativeButton("Annuler", null);
        builder.show();
    }

    /** Dialog changement d'email */
    private void showChangeEmailDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 0);

        EditText etNewEmail = new EditText(this);
        etNewEmail.setHint("Nouvelle adresse e-mail");
        etNewEmail.setInputType(android.text.InputType.TYPE_CLASS_TEXT
            | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        etNewEmail.setText(session.getEmail());
        layout.addView(etNewEmail);

        new AlertDialog.Builder(this)
            .setTitle("Changer l'e-mail")
            .setView(layout)
            .setPositiveButton("Modifier", (d, w) -> {
                String newEmail = etNewEmail.getText().toString().trim();
                if (!Patterns.EMAIL_ADDRESS.matcher(newEmail).matches()) {
                    Toast.makeText(this, "E-mail invalide", Toast.LENGTH_SHORT).show();
                    return;
                }
                changerEmail(newEmail);
            })
            .setNegativeButton("Annuler", null)
            .show();
    }

    /** Volley POST — changement mot de passe */
    private void changerMotDePasse(String oldPwd, String newPwd) {
        StringRequest request = new StringRequest(Request.Method.POST,
            ApiConfig.URL_CHANGE_PASSWORD,
            response -> {
                try {
                    JSONObject json = new JSONObject(response);
                    Toast.makeText(this,
                        json.getString(ApiConfig.KEY_MESSAGE), Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Toast.makeText(this, "Erreur serveur", Toast.LENGTH_SHORT).show();
                }
            },
            error -> Toast.makeText(this, "Erreur réseau", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("user_id",      String.valueOf(session.getUserId()));
                p.put("old_password", oldPwd);
                p.put("new_password", newPwd);
                return p;
            }
        };
        MySingleton.getInstance(this).addToRequestQueue(request);
    }

    /** Volley POST — changement email */
    private void changerEmail(String newEmail) {
        StringRequest request = new StringRequest(Request.Method.POST,
            ApiConfig.URL_CHANGE_EMAIL,
            response -> {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.getBoolean(ApiConfig.KEY_SUCCESS)) {
                        // Mettre à jour la session
                        session.updateEmail(newEmail);
                        tvEmail.setText(newEmail);
                    }
                    Toast.makeText(this,
                        json.getString(ApiConfig.KEY_MESSAGE), Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Toast.makeText(this, "Erreur serveur", Toast.LENGTH_SHORT).show();
                }
            },
            error -> Toast.makeText(this, "Erreur réseau", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("user_id",   String.valueOf(session.getUserId()));
                p.put("new_email", newEmail);
                return p;
            }
        };
        MySingleton.getInstance(this).addToRequestQueue(request);
    }
}
