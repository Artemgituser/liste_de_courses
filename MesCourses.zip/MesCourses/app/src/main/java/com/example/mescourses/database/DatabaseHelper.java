package com.example.mescourses.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mescourses.models.Produit;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String BASE_NOM = "mescourses.db";
    private static final int BASE_VERSION = 1;

    // Table produits (base + courses + archivage unifiée par statut)
    public static final String NOM_TABLE = "produits";
    public static final String COL0 = "id";
    public static final String COL1 = "nom";
    public static final String COL2 = "quantite";
    public static final String COL3 = "rayon";
    public static final String COL4 = "statut";
    // statut : 0=base, 1=courses en cours, 2=archivé

    private static final String CREATE_TABLE_PRODUITS =
        "CREATE TABLE " + NOM_TABLE + " (" +
                COL0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1 + " TEXT NOT NULL, " +
                COL2 + " INTEGER DEFAULT 1, " +
                COL3 + " TEXT, " +
                COL4 + " INTEGER DEFAULT 0" +
        ");";

    // Singleton
    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context ctx) {
        if (instance == null) {
            instance = new DatabaseHelper(ctx.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, BASE_NOM, null, BASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_PRODUITS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + NOM_TABLE);
        onCreate(db);
    }


    public long insertProduit(String nom, int quantite, String rayon) {
        if (produitExiste(nom, rayon)) return -1;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL1,      nom.trim());
        cv.put(COL2, quantite);
        cv.put(COL3,    rayon.trim());
        cv.put(COL4,   Produit.STATUT_BASE);
        long id = db.insert(NOM_TABLE, null, cv);
        db.close();
        return id;
    }

   //Vérifie un produit avec son nom+rayon
    public boolean produitExiste(String nom, String rayon) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(NOM_TABLE,
            new String[]{COL0},
            "LOWER(" + COL1 + ")=? AND LOWER(" + COL3 + ")=?",
            new String[]{nom.trim().toLowerCase(), rayon.trim().toLowerCase()},
            null, null, null);
        boolean existe = c.getCount() > 0;
        c.close();
        db.close();
        return existe;
    }


    public List<Produit> getAllProduits() {
        return getByStatut(Produit.STATUT_BASE);
    }


    public List<Produit> getProduitsCourses() {
        return getByStatut(Produit.STATUT_COURSES);
    }


    public List<Produit> getProduitsArchives() {
        return getByStatut(Produit.STATUT_ARCHIVE);
    }


    private List<Produit> getByStatut(int statut) {
        List<Produit> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String orderBy = (statut == Produit.STATUT_ARCHIVE)
            ? COL1 + " COLLATE NOCASE ASC, " + COL3 + " COLLATE NOCASE ASC"
            : COL3 + " COLLATE NOCASE ASC, " + COL1 + " COLLATE NOCASE ASC";

        Cursor c = db.query(NOM_TABLE,
            null,
            COL4 + "=?",
            new String[]{String.valueOf(statut)},
            null, null, orderBy);

        if (c.moveToFirst()) {
            do {
                list.add(cursorToProduit(c));
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }


    public Produit getProduitById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(NOM_TABLE, null,
            COL0 + "=?", new String[]{String.valueOf(id)},
            null, null, null);
        Produit p = null;
        if (c.moveToFirst()) p = cursorToProduit(c);
        c.close();
        db.close();
        return p;
    }

//METTRE NOM DE PRODUIT

    public int updateProduit(int id, String nom, int quantite, String rayon) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL1,      nom.trim());
        cv.put(COL2, quantite);
        cv.put(COL3,    rayon.trim());
        int rows = db.update(NOM_TABLE, cv, COL0 + "=?",
            new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    /** Change le statut d'un produit (base / courses / archivé) */
    public int updateStatut(int id, int newStatut) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL4, newStatut);
        int rows = db.update(NOM_TABLE, cv, COL0 + "=?",
            new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }


    public int deleteProduit(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(NOM_TABLE, COL0 + "=?",
            new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }


    private Produit cursorToProduit(Cursor c) {
        return new Produit(
            c.getInt(c.getColumnIndexOrThrow(COL0)),
            c.getString(c.getColumnIndexOrThrow(COL1)),
            c.getInt(c.getColumnIndexOrThrow(COL2)),
            c.getString(c.getColumnIndexOrThrow(COL3)),
            c.getInt(c.getColumnIndexOrThrow(COL4))
        );
    }
}
